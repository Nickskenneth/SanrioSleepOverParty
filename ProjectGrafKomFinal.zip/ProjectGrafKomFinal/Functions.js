//Function Mario
//LINGKARAN
function drawCircle(x, y, z, radius, r, g, b) {
  var vertices = [];
  for (let i = 0; i <= 360; i++) {
    var angleInRadians = (i * Math.PI) / 180;
    var newX = x; // X-coordinate remains the same
    var newY = y + Math.cos(angleInRadians) * radius; // Rotate around X-axis
    var newZ = z + Math.sin(angleInRadians) * radius; // Translate along Z-axis
    vertices.push(newX);
    vertices.push(newY);
    vertices.push(newZ);
    vertices.push(r);
    vertices.push(g);
    vertices.push(b);
  }
  return vertices;
}


//TABUNG/CYLINDER
function createCylinder(x, y, z, length, radius, latitudeBands, longitudeBands, rotationAngle, r, g, b) {
  const positions = [];
  const indices = [];
  const offsetX = -length * 0.5;
  const offsetY = -radius * 0.5;

  // Bagian atas tabung (lingkaran setengah)
  for (let long = 0; long <= longitudeBands; long++) {
    const phi = (long * 2 * Math.PI) / longitudeBands;
    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    const xPosition = offsetX + length;
    const yPosition = offsetY + radius * cosPhi;
    const zPosition = z + radius * sinPhi;

    const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
    const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

    positions.push(rotatedX, rotatedY, zPosition, r, g, b);
  }

  // Bagian bawah tabung (lingkaran setengah)
  for (let long = 0; long <= longitudeBands; long++) {
    const phi = (long * 2 * Math.PI) / longitudeBands;
    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    const xPosition = offsetX;
    const yPosition = offsetY + radius * cosPhi;
    const zPosition = z + radius * sinPhi;

    const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
    const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

    positions.push(rotatedX, rotatedY, zPosition, r, g, b);
  }

  // Tutup bagian atas tabung (lingkaran setengah)
  const topIndexOffset = positions.length / 6; // Offset untuk indeks pada bagian atas tabung
  for (let long = 0; long <= longitudeBands; long++) {
    const phi = (long * 2 * Math.PI) / longitudeBands;
    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    const xPosition = offsetX + length;
    const yPosition = offsetY + radius * cosPhi;
    const zPosition = z + radius * sinPhi;

    const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
    const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

    positions.push(rotatedX, rotatedY, zPosition, r, g, b);
  }

  // Tutup bagian bawah tabung (lingkaran setengah)
  const bottomIndexOffset = positions.length / 6; // Offset untuk indeks pada bagian bawah tabung
  for (let long = 0; long <= longitudeBands; long++) {
    const phi = (long * 2 * Math.PI) / longitudeBands;
    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    const xPosition = offsetX;
    const yPosition = offsetY + radius * cosPhi;
    const zPosition = z + radius * sinPhi;

    const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
    const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

    positions.push(rotatedX, rotatedY, zPosition, r, g, b);
  }

  // Sisi tabung
  for (let lat = 0; lat <= latitudeBands; lat++) {
    const theta = (lat * Math.PI) / (1 * latitudeBands);
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= longitudeBands; long++) {
      const phi = (long * 2 * Math.PI) / longitudeBands;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const xPosition = offsetX + length * cosTheta;
      const yPosition = offsetY + radius * cosPhi * sinTheta;
      const zPosition = z + radius * sinPhi * sinTheta;

      const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
      const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

      positions.push(rotatedX, rotatedY, zPosition, r, g, b);
    }
  }

  // Indeks untuk menghubungkan verteks
  for (let lat = 0; lat < latitudeBands; lat++) {
    for (let long = 0; long < longitudeBands; long++) {
      const first = lat * (longitudeBands + 1) + long;
      const second = first + longitudeBands + 1;

      indices.push(first, second, first + 1);
      indices.push(second, second + 1, first + 1);
    }
  }

  // Indeks untuk menghubungkan verteks pada tutup atas tabung
  for (let long = 0; long < longitudeBands; long++) {
    indices.push(topIndexOffset + long, topIndexOffset + long + 1, topIndexOffset + long + 2);
  }

  // Indeks untuk menghubungkan verteks pada tutup bawah tabung
  for (let long = 0; long < longitudeBands; long++) {
    indices.push(bottomIndexOffset + long, bottomIndexOffset + long + 2, bottomIndexOffset + long + 1);
  }

  return { positions, indices };
}


//ELIPS
function elips(radiusX, radiusY, radiusZ, segments, r, g, b) {
  const vertices = [];
  const indices = [];

  // Generate vertices for both the top and bottom halves of the frisbee
  for (let i = 0; i <= segments; i++) {
    const lat = (Math.PI * i) / segments;
    const sinLat = Math.sin(lat);
    const cosLat = Math.cos(lat);

    // Adjust the y-coordinate based on the latitude to create a frisbee-like shape
    const adjustedY = cosLat * 0.4; // Adjust this value to make the shape flatter or rounder

    for (let j = 0; j <= segments; j++) {
      const lng = (2 * Math.PI * j) / segments;
      const sinLng = Math.sin(lng);
      const cosLng = Math.cos(lng);

      const x = cosLng * sinLat;
      const y = adjustedY; // Use the adjusted y-coordinate
      const z = sinLng * sinLat;

      // Push vertices for the top half of the frisbee
      vertices.push(radiusX * x, radiusY * y, radiusZ * z, r, g, b);

      // Push vertices for the bottom half of the frisbee
      vertices.push(radiusX * x, -radiusY * y, radiusZ * z, r, g, b);

      if (i < segments && j < segments) {
        let first = i * (segments + 1) + j;
        let second = first + segments + 1;

        // Push indices for the top half of the frisbee
        indices.push(first, second, first + 1);
        indices.push(second, second + 1, first + 1);

        // Push indices for the bottom half of the frisbee
        indices.push(
          first + segments + 1,
          second + segments + 1,
          first + segments + 2
        );
        indices.push(
          second + segments + 1,
          second + segments + 2,
          first + segments + 2
        );
      }
    }
  }

  return { vertices, indices };
}


//SPHERE/BOLA
function createSphere(x, y, z, xRadius, yRadius, zRadius, latitudeBands, longitudeBands, r, g, b) {
  const positions = [];
  const indices = [];

  for (let lat = 0; lat <= latitudeBands; lat++) {
    const theta = (lat * Math.PI) / latitudeBands;
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= longitudeBands; long++) {
      const phi = (long * 2 * Math.PI) / longitudeBands;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const xPosition = x + xRadius * cosPhi * sinTheta;
      const yPosition = y + yRadius * sinPhi * sinTheta;
      const zPosition = z + zRadius * cosTheta;

      positions.push(xPosition, yPosition, zPosition, r, g, b);
    }
  }

  for (let lat = 0; lat < latitudeBands; lat++) {
    for (let long = 0; long < longitudeBands; long++) {
      const first = lat * (longitudeBands + 1) + long;
      const second = first + longitudeBands + 1;

      indices.push(first, second, first + 1);
      indices.push(second, second + 1, first + 1);
    }
  }

  return { positions, indices };
}


//SETENGAH LINGKARAN/SETENGAH BOLA
function createHalfSphere(x, y, z, xRadius, yRadius, zRadius, latitudeBands, longitudeBands, r, g, b) {
  const positions = [];
  const indices = [];

  for (let lat = 0; lat <= latitudeBands; lat++) { // Mengubah batas lat menjadi latitudeBands (tanpa dibagi 7)
    const theta = (lat * Math.PI) / (1 * latitudeBands); // Mengubah batas theta menjadi setengah lingkaran
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= longitudeBands; long++) { // Mengubah loop menjadi penuh lingkaran
      const phi = (long * Math.PI) / longitudeBands;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const xPosition = x + xRadius * cosPhi * sinTheta;
      const yPosition = y + yRadius * sinPhi * sinTheta;
      const zPosition = z + zRadius * cosTheta;

      positions.push(xPosition, yPosition, zPosition, r, g, b);
    }
  }

  for (let lat = 0; lat < latitudeBands; lat++) { // Mengubah batas lat menjadi latitudeBands (tanpa dibagi 7)
    for (let long = 0; long < longitudeBands; long++) { // Mengubah loop menjadi penuh lingkaran
      const first = lat * (longitudeBands + 1) + long;
      const second = first + longitudeBands + 1;

      indices.push(first, second, first + 1);
      indices.push(second, second + 1, first + 1);
    }
  }

  return { positions, indices };
}


//CONE
function createCone(x, y, z, xRadius, yRadius, zRadius, latitudeBands, longitudeBands, rotationAngle, r, g, b) {
  const positions = [];
  const indices = [];
  const offsetX = x; // Tentukan offset agar posisi objek tidak terlalu jauh dari (0, 0, 0)
  const offsetY = y - yRadius;
  const offsetZ = z;

  for (let lat = 0; lat <= latitudeBands; lat++) {
    const theta = (lat * Math.PI) / (1 * latitudeBands);
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= longitudeBands; long++) {
      const phi = (long * Math.PI) / longitudeBands;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const xPosition = offsetX + xRadius * cosPhi * sinTheta;
      const yPosition = offsetY + yRadius * sinPhi * sinTheta;
      const zPosition = offsetZ + zRadius * cosTheta;

      const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle);
      const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle);

      positions.push(rotatedX, rotatedY, zPosition, r, g, b);
    }
  }

  for (let lat = 0; lat < latitudeBands; lat++) {
    for (let long = 0; long < longitudeBands; long++) {
      const first = lat * (longitudeBands + 1) + long;
      const second = first + longitudeBands + 1;

      indices.push(first, second, first + 1);
      indices.push(second, second + 1, first + 1);
    }
  }

  return { positions, indices };
}


//CONE LANCIP
function createCone1(radius, height, x0, y0, z0, segments, red = 0, green = 0, blue = 0, rotationAngle = 0) {
  const positions = [];
  const indices = [];

  const angleIncrement = (2 * Math.PI) / segments;

  // Basis lingkaran kerucut
  for (let i = 0; i < segments; i++) {
    const theta = i * angleIncrement;
    const x = radius * Math.cos(theta);
    const z = radius * Math.sin(theta);

    // Rotasi koordinat
    const rotatedX = x * Math.cos(rotationAngle) + z * Math.sin(rotationAngle); // Ubah z0 menjadi z
    const rotatedZ = -x * Math.sin(rotationAngle) + z * Math.cos(rotationAngle); // Ubah y0 menjadi z

    // Vertex dengan warna yang diberikan
    positions.push(rotatedX + x0, y0, rotatedZ + z0, red, green, blue); // Tidak ada perubahan pada y0

    // Indices untuk menggambar wajah (faces)
    if (i < segments - 1) {
      indices.push(i, segments, i + 1); // Menghubungkan setiap titik basis dengan titik puncak
    } else {
      indices.push(i, segments, 0); // Menghubungkan titik terakhir di lingkaran dengan titik awal untuk menutup kerucut
    }
  }

  // Puncak kerucut
  positions.push(x0, y0 + height, z0, red, green, blue); // Warna puncak sama dengan warna basis

  return { positions, indices };
}


//LEHER DI HELLO KITTY
function createLeher(startX, startY, startZ, x1, y1, z1, red, green, blue) {
  var vertices = [];

  vertices.push(0 + startX - x1, startY, startZ, red, green, blue); //0-kanan bawah
  vertices.push(0 - startX + x1, startY, startZ, red, green, blue); //1- kiribawah
  vertices.push(0 - startX, startY + y1, startZ - z1, red, green, blue); //2 - kiri atas
  vertices.push(0 + startX, startY + y1, startZ - z1, red, green, blue); //3 - kanan atas

  return vertices;
}

function leherFaces() {
  var indices = [];

  indices.push(0);
  indices.push(1);
  indices.push(2);

  indices.push(0);
  indices.push(2);
  indices.push(3);

  return indices;
}

//Function Marvel

//Sphere Marvel
function createSphere2(x, y, z, radiusX, radiusY, radiusZ, latitudeSegments, longitudeSegments, r, g, b) {
  const vertices = [];
  const faces = [];

  const angleIncrement = (2 * Math.PI) / longitudeSegments;

  for (let lat = 0; lat <= latitudeSegments; lat++) {
    const theta = (lat * Math.PI) / latitudeSegments;
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= longitudeSegments; long++) {
      const phi = (long * angleIncrement);
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const xCoord = x + radiusX * cosPhi * sinTheta;
      const yCoord = y + radiusY * sinPhi * sinTheta;
      const zCoord = z + radiusZ * cosTheta;

      vertices.push(xCoord, yCoord, zCoord, r, g, b);
    }
  }

  for (let lat = 0; lat < latitudeSegments; lat++) {
    for (let long = 0; long < longitudeSegments; long++) {
      const first = lat * (longitudeSegments + 1) + long;
      const second = first + longitudeSegments + 1;

      faces.push(first, second, first + 1);
      faces.push(second, second + 1, first + 1);
    }
  }

  return { vertices, faces };
}

//Half-Sphere Marvel
function createHalfSphere2(x, y, z, radiusX, radiusY, radiusZ, latitudeSegments, longitudeSegments, r, g, b) {
  const vertices = [];
  const faces = [];

  for (let lat = 0; lat <= latitudeSegments; lat++) {
    const theta = (lat * Math.PI) / (1 * latitudeSegments);
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= longitudeSegments; long++) {
      const phi = (long * Math.PI) / longitudeSegments;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const xPosition = x + radiusX * cosPhi * sinTheta;
      const yPosition = y + radiusY * sinPhi * sinTheta;
      const zPosition = z + radiusZ * cosTheta;

      vertices.push(xPosition, yPosition, zPosition, r, g, b);
    }
  }
  const bottomVertexIndex = vertices.length / 6;
  const bottomYPosition = y - radiusY * 0;

  for (let long = 0; long <= longitudeSegments; long++) {
    const phi = (long * Math.PI) / longitudeSegments;
    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    const xPosition = x + radiusX * cosPhi;
    const zPosition = z + radiusZ * sinPhi;

    vertices.push(xPosition, bottomYPosition, zPosition, r, g, b);
  }
  for (let long = 0; long < longitudeSegments; long++) {
    const first = bottomVertexIndex + long;
    const second = bottomVertexIndex + long + 1;

    faces.push(first, second, bottomVertexIndex);
  }

  for (let lat = 0; lat < latitudeSegments; lat++) {
    for (let long = 0; long < longitudeSegments; long++) {
      const first = lat * (longitudeSegments + 1) + long;
      const second = first + longitudeSegments + 1;

      faces.push(first, second, first + 1);
      faces.push(second, second + 1, first + 1);
    }
  }

  return { vertices, faces };
}

// Trapesium Marvel
function createRightAngleTrapezoidalPrism(x, y, z, baseWidth, topWidth, height, depth, r, g, b) {
  const vertices = [
    // Bottom face vertices
    x - baseWidth / 2, y, z - depth / 2, r, g, b,  // 0
    x + baseWidth / 2, y, z - depth / 2, r, g, b,  // 1
    x + topWidth / 2, y + height, z - depth / 2, r, g, b,  // 2
    x - topWidth / 2, y + height, z - depth / 2, r, g, b,  // 3

    // Top face vertices
    x - baseWidth / 2, y, z + depth / 2, r, g, b,  // 4
    x + baseWidth / 2, y, z + depth / 2, r, g, b,  // 5
    x + topWidth / 2, y + height, z + depth / 2, r, g, b,  // 6
    x - topWidth / 2, y + height, z + depth / 2, r, g, b   // 7
  ];

  const faces = [
    // Bottom face
    0, 1, 2,
    0, 2, 3,

    // Top face
    4, 6, 5,
    4, 7, 6,

    // Side faces
    0, 4, 5,
    0, 5, 1,
    1, 5, 6,
    1, 6, 2,
    2, 6, 7,
    2, 7, 3,
    3, 7, 4,
    3, 4, 0
  ];

  return { vertices, faces };
}

// Leher Paruh
function leherParuh() {
  var faces = [];

  faces.push(3);
  faces.push(0);
  faces.push(2);

  faces.push(3);
  faces.push(1);
  faces.push(2);

  faces.push(2);
  faces.push(0);
  faces.push(4);

  faces.push(2);
  faces.push(1);
  faces.push(4);

  faces.push(4);
  faces.push(0);
  faces.push(3);

  faces.push(4);
  faces.push(1);
  faces.push(3);

  faces.push(5);
  faces.push(0);
  faces.push(6);

  faces.push(5);
  faces.push(1);
  faces.push(6);

  faces.push(7);
  faces.push(0);
  faces.push(6);

  faces.push(7);
  faces.push(1);
  faces.push(6);

  faces.push(5);
  faces.push(0);
  faces.push(7);

  faces.push(5);
  faces.push(1);
  faces.push(7);

  return faces;
}

// Paruh Dalam Marvel
function createParuhDalam(startX, startY, startZ, x1, x2, y1, z1, red, green, blue) {
  var vertices = [];

  vertices.push(x2 + startX, startY, startZ, red, green, blue); //0-kanan bawah
  vertices.push(x2 - startX, startY, startZ, red, green, blue); //1- kiribawah
  vertices.push(x2, startY + y1 / 2, startZ, red, green, blue); //2- tengah atas

  return vertices;
}

// Leher Paruh Marvel
function leherParuhDalam() {
  var faces = [];

  faces.push(2);
  faces.push(0);
  faces.push(1);

  return faces;
}

// Paruh
function createParuh(startX, startY, startZ, x1, x2, y1, z1, red, green, blue, red1, green1, blue1) {
  var vertices = [];

  vertices.push(x2 + startX, startY, startZ, red, green, blue);
  vertices.push(x2 - startX, startY, startZ, red, green, blue);
  vertices.push(x2, startY + y1, startZ, red, green, blue);
  vertices.push(x2, startY + y1 / 2, startZ + z1, red1, green1, blue1);
  vertices.push(x2, startY + y1 / 2, startZ, red1, green1, blue1);

  vertices.push(x2, startY + y1 / 2 - 0.4, startZ + z1, red, green, blue);
  vertices.push(x2, startY, startZ, red, green, blue);
  vertices.push(x2, startY + y1 / 2 - 0.4, startZ, red, green, blue);

  return vertices;
}

//Cone Marvel
function createCone2(radius, height, x0, y0, z0, segments, tiltAngle = 0, red = 0, green = 0, blue = 0) {
  const vertices = [];
  const faces = [];

  const angleIncrement = (2 * Math.PI) / segments;

  // Basis lingkaran kerucut
  for (let i = 0; i < segments; i++) {
    const theta = i * angleIncrement + tiltAngle;
    const x = radius * Math.cos(theta);
    const z = radius * Math.sin(theta);

    vertices.push(x + x0, y0, z + z0, red, green, blue);

    if (i < segments - 1) {
      faces.push(i, segments, i + 1);
    } else {
      faces.push(i, segments, 0);
    }
  }

  // Puncak kerucut
  vertices.push(x0, y0 + height, z0, red, green, blue); // Warna puncak sama dengan warna basis

  return { vertices, faces };
}

// Kurva Marvel
function bezierCurve2(controlPoints, numPoints) {
  const points = [];
  for (let i = 0; i <= numPoints; i++) {
      const t = i / numPoints;
      const x = Math.pow(1 - t, 3) * controlPoints[0][0] + 
                3 * Math.pow(1 - t, 2) * t * controlPoints[1][0] + 
                3 * (1 - t) * Math.pow(t, 2) * controlPoints[2][0] + 
                Math.pow(t, 3) * controlPoints[3][0];
              const y = Math.pow(1 - t, 3) * controlPoints[0][1] + 
              3 * Math.pow(1 - t, 2) * t * controlPoints[1][1] + 
          3 * (1 - t) * Math.pow(t, 2) * controlPoints[2][1] + 
          Math.pow(t, 3) * controlPoints[3][1];
          points.push([x, y]);
  }
  return points;
}

function createBezierRectangularPrism2(x0, y0, x1, y1, x2, y2, x3, y3, z0, red, green, blue, section) {
  var vertices = [];
  var faces = [];

  // Generate bezier curve points
  var bezierCurvePoints = bezierCurve2([[x0, y0], [x1, y1], [x2, y2], [x3, y3]], section);

  // Generate vertices based on the bezier curve points
  for (let i = 0; i <= section; i++) {
      var x = bezierCurvePoints[i][0]; // x-coordinate from the bezier curve
      var y = bezierCurvePoints[i][1]; // y-coordinate from the bezier curve

      // Push vertices
      vertices.push(x, y, z0, red, green, blue); // Top vertices
      vertices.push(x, y - 0.05, z0, red, green, blue); // Bottom vertices
  }

  // Generate faces
  for (let i = 0; i < section; i++) {
      var startIndex = i * 2;
      faces.push(startIndex, startIndex + 1, startIndex + 3);
      faces.push(startIndex, startIndex + 3, startIndex + 2);
  }

  return [vertices, faces];
}

//Function Nicholas
function createCylinder3(x, y, z, length, radius, latitudeBands, longitudeBands, rotationAngle, r, g, b) {
  const positions = [];
  const indices = [];
  const offsetX = -length * 0.5; // Mengatur offset agar objek berada di tengah pada koordinat (0, 0, 0)
  const offsetY = -radius * 0.5;

  // Bagian atas tabung (lingkaran setengah)
  for (let long = 0; long <= longitudeBands; long++) {
    const phi = (long * 2 * Math.PI) / longitudeBands;
    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    const xPosition = offsetX + length;
    const yPosition = offsetY + radius * cosPhi;
    const zPosition = z + radius * sinPhi;

    const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
    const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

    positions.push(rotatedX, rotatedY, zPosition, r, g, b);
  }

  // Bagian bawah tabung (lingkaran setengah)
  for (let long = 0; long <= longitudeBands; long++) {
    const phi = (long * 2 * Math.PI) / longitudeBands;
    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    const xPosition = offsetX;
    const yPosition = offsetY + radius * cosPhi;
    const zPosition = z + radius * sinPhi;

    const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
    const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

    positions.push(rotatedX, rotatedY, zPosition, r, g, b);
  }

  // Tutup bagian atas tabung (lingkaran setengah)
  const topIndexOffset = positions.length / 6; // Offset untuk indeks pada bagian atas tabung
  for (let long = 0; long <= longitudeBands; long++) {
    const phi = (long * 2 * Math.PI) / longitudeBands;
    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    const xPosition = offsetX + length;
    const yPosition = offsetY + radius * cosPhi;
    const zPosition = z + radius * sinPhi;

    const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
    const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

    positions.push(rotatedX, rotatedY, zPosition, r, g, b);
  }

  // Tutup bagian bawah tabung (lingkaran setengah)
  const bottomIndexOffset = positions.length / 6; // Offset untuk indeks pada bagian bawah tabung
  for (let long = 0; long <= longitudeBands; long++) {
    const phi = (long * 2 * Math.PI) / longitudeBands;
    const sinPhi = Math.sin(phi);
    const cosPhi = Math.cos(phi);

    const xPosition = offsetX;
    const yPosition = offsetY + radius * cosPhi;
    const zPosition = z + radius * sinPhi;

    const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
    const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

    positions.push(rotatedX, rotatedY, zPosition, r, g, b);
  }

  // Sisi tabung
  for (let lat = 0; lat <= latitudeBands; lat++) {
    const theta = (lat * Math.PI) / (1 * latitudeBands);
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= longitudeBands; long++) {
      const phi = (long * 2 * Math.PI) / longitudeBands;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const xPosition = offsetX + length * cosTheta;
      const yPosition = offsetY + radius * cosPhi * sinTheta;
      const zPosition = z + radius * sinPhi * sinTheta;

      const rotatedX = xPosition * Math.cos(rotationAngle) - yPosition * Math.sin(rotationAngle) + x;
      const rotatedY = xPosition * Math.sin(rotationAngle) + yPosition * Math.cos(rotationAngle) + y;

      positions.push(rotatedX, rotatedY, zPosition, r, g, b);
    }
  }

  // Indeks untuk menghubungkan verteks
  for (let lat = 0; lat < latitudeBands; lat++) {
    for (let long = 0; long < longitudeBands; long++) {
      const first = lat * (longitudeBands + 1) + long;
      const second = first + longitudeBands + 1;

      indices.push(first, second, first + 1);
      indices.push(second, second + 1, first + 1);
    }
  }

  // Indeks untuk menghubungkan verteks pada tutup atas tabung
  for (let long = 0; long < longitudeBands; long++) {
    indices.push(topIndexOffset + long, topIndexOffset + long + 1, topIndexOffset + long + 2);
  }

  // Indeks untuk menghubungkan verteks pada tutup bawah tabung
  for (let long = 0; long < longitudeBands; long++) {
    indices.push(bottomIndexOffset + long, bottomIndexOffset + long + 2, bottomIndexOffset + long + 1);
  }

  return { positions, indices };
}


function createSphere3(x,y,z,xRadius,yRadius,zRadius,latitudeBands,longitudeBands,r,g,b) {
  const positions = [];
  const indices = [];

  for (let lat = 0; lat <= latitudeBands; lat++) {
    const theta = (lat * Math.PI) / latitudeBands;
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= longitudeBands; long++) {
      const phi = (long * 2 * Math.PI) / longitudeBands;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const xPosition = x + xRadius * cosPhi * sinTheta;
      const yPosition = y + yRadius * sinPhi * sinTheta;
      const zPosition = z + zRadius * cosTheta;

      positions.push(xPosition, yPosition, zPosition, r, g, b);
    }
  }

  for (let lat = 0; lat < latitudeBands; lat++) {
    for (let long = 0; long < longitudeBands; long++) {
      const first = lat * (longitudeBands + 1) + long;
      const second = first + longitudeBands + 1;

      indices.push(first, second, first + 1);
      indices.push(second, second + 1, first + 1);
    }
  }

  return { positions, indices };
}


function createHalfSphere3(
  x,
  y,
  z,
  xRadius,
  yRadius,
  zRadius,
  latitudeBands,
  longitudeBands,
  r,
  g,
  b
) {
  const positions = [];
  const indices = [];

  for (let lat = 0; lat <= latitudeBands; lat++) { // Mengubah batas lat menjadi latitudeBands (tanpa dibagi 7)
    const theta = (lat * Math.PI) / (1 * latitudeBands); // Mengubah batas theta menjadi setengah lingkaran
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= longitudeBands; long++) { // Mengubah loop menjadi penuh lingkaran
      const phi = (long * Math.PI) / longitudeBands;
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const xPosition = x + xRadius * cosPhi * sinTheta;
      const yPosition = y + yRadius * sinPhi * sinTheta;
      const zPosition = z + zRadius * cosTheta;

      positions.push(xPosition, yPosition, zPosition, r, g, b);
    }
  }

  for (let lat = 0; lat < latitudeBands; lat++) { // Mengubah batas lat menjadi latitudeBands (tanpa dibagi 7)
    for (let long = 0; long < longitudeBands; long++) { // Mengubah loop menjadi penuh lingkaran
      const first = lat * (longitudeBands + 1) + long;
      const second = first + longitudeBands + 1;

      indices.push(first, second, first + 1);
      indices.push(second, second + 1, first + 1);
    }
  }

  return { positions, indices };
}


//Function Assets

//KASUR
function createKasur(startX, startY, startZ, x1, x2, y1, y2, z1, z2, colors) {
  var vertices = [];

  //depan
  vertices.push(x2 + startX, startY, z2 + startZ, ...colors[0]); //kanan bawah 0
  vertices.push(x2 - startX, startY, z2 + startZ, ...colors[0]); //kiri bawah 1
  vertices.push(x2 - startX, startY + y1, z2 + startZ, ...colors[1]); //kiri atas 2
  vertices.push(x2 + startX, startY + y1, z2 + startZ, ...colors[1]); //kanan atas 3

  //belakang
  vertices.push(x2 + startX, startY, z2 - startZ, ...colors[0]); //kanan bawah 4
  vertices.push(x2 - startX, startY, z2 - startZ, ...colors[0]); //kiri bawah 5
  vertices.push(x2 - startX, startY + y1, z2 - startZ, ...colors[1]); //kiri atas 6
  vertices.push(x2 + startX, startY + y1, z2 - startZ, ...colors[1]); //kanan atas 7

  //bantal depan
  vertices.push(x2 + startX - x1, startY + y1 + 0.1, z2 - startZ + z1, ...colors[0]); //kanan bawah 8
  vertices.push(x2 - startX + x1, startY + y1 + 0.1, z2 - startZ + z1, ...colors[0]); //kiri bawah 9
  vertices.push(x2 - startX + x1, startY + y1 + 0.1 + y2, z2 - startZ + z1, ...colors[1]); //kiri atas 10
  vertices.push(x2 + startX - x1, startY + y1 + 0.1 + y2, z2 - startZ + z1, ...colors[1]); //kanan atas 11

  //bantal belakang
  vertices.push(x2 + startX - x1, startY + y1 + 0.1, z2 - startZ + 1, ...colors[0]); //kanan bawah 12
  vertices.push(x2 - startX + x1, startY + y1 + 0.1, z2 - startZ + 1, ...colors[0]); //kiri bawah 13
  vertices.push(x2 - startX + x1, startY + y1 + 0.1 + y2, z2 - startZ + 1, ...colors[1]); //kiri atas 14
  vertices.push(x2 + startX - x1, startY + y1 + 0.1 + y2, z2 - startZ + 1, ...colors[1]); //kanan atas 15

  //selimut atas belakang
  vertices.push(x2 + startX - 1, startY + y1 + 0.1, z2 - startZ + z1 + 2, ...colors[0]); //kanan bawah 16
  vertices.push(x2 - startX + 1, startY + y1 + 0.1, z2 - startZ + z1 + 2, ...colors[0]); //kiri bawah 17
  vertices.push(x2 - startX + 1, startY + y1 + 0.1 + y2, z2 - startZ + z1 + 2, ...colors[2]); //kiri atas 18
  vertices.push(x2 + startX - 1, startY + y1 + 0.1 + y2, z2 - startZ + z1 + 2, ...colors[2]); //kanan atas 19

  //selimut atas depan
  vertices.push(x2 + startX - 1, startY + y1 + 0.1, z2 - startZ + z1 + 4, ...colors[0]); //kanan bawah 20
  vertices.push(x2 - startX + 1, startY + y1 + 0.1, z2 - startZ + z1 + 4, ...colors[0]); //kiri bawah 21
  vertices.push(x2 - startX + 1, startY + y1 + 0.1 + y2, z2 - startZ + z1 + 4, ...colors[2]); //kiri atas 22
  vertices.push(x2 + startX - 1, startY + y1 + 0.1 + y2, z2 - startZ + z1 + 4, ...colors[2]); //kanan atas 23

  //selimut bawah belakang
  vertices.push(x2 + startX - 1, startY + y1 + 0.1, z2 - startZ + z1 + 4.01, ...colors[3]); //kanan bawah 24
  vertices.push(x2 - startX + 1, startY + y1 + 0.1, z2 - startZ + z1 + 4.01, ...colors[4]); //kiri bawah 25
  vertices.push(x2 - startX + 1, startY + y1 + 0.1 + y2, z2 - startZ + z1 + 4.01, ...colors[4]); //kiri atas 26
  vertices.push(x2 + startX - 1, startY + y1 + 0.1 + y2, z2 - startZ + z1 + 4.01, ...colors[3]); //kanan atas 27

  //selimut bawah depan
  vertices.push(x2 + startX - 1, startY + y1 + 0.1, z2 + startZ - 0.5, ...colors[3]); //kanan bawah 28
  vertices.push(x2 - startX + 1, startY + y1 + 0.1, z2 + startZ - 0.5, ...colors[4]); //kiri bawah 29
  vertices.push(x2 - startX + 1, startY + y1 + 0.1 + y2, z2 + startZ - 0.5, ...colors[4]); //kiri atas 30
  vertices.push(x2 + startX - 1, startY + y1 + 0.1 + y2, z2 + startZ - 0.5, ...colors[3]); //kanan atas 31

  return vertices;
}

var colors = [
  [0.5, 0.5, 0.5], //0
  [1, 1, 1], //1
  [0.9, 0.9, 0.9], //2
  [0, 0.5, 1], //3
  [0.6, 0.8, 1], //4
];

function kasurFaces() {
  var indices = [];

  //depan
  indices.push(0);
  indices.push(1);
  indices.push(2);

  indices.push(0);
  indices.push(3);
  indices.push(2);

  //belakang
  indices.push(4);
  indices.push(5);
  indices.push(6);

  indices.push(4);
  indices.push(7);
  indices.push(6);

  //sisi kanan
  indices.push(4);
  indices.push(0);
  indices.push(3);

  indices.push(4);
  indices.push(7);
  indices.push(3);

  //sisi kiri
  indices.push(5);
  indices.push(1);
  indices.push(2);

  indices.push(5);
  indices.push(6);
  indices.push(2);

  //bagian bawah
  indices.push(0);
  indices.push(4);
  indices.push(5);

  indices.push(0);
  indices.push(1);
  indices.push(5);

  //bagian atas
  indices.push(3);
  indices.push(7);
  indices.push(6);

  indices.push(3);
  indices.push(2);
  indices.push(6);

  return indices;
}

function bantalFaces() {
  var indices = [];

  //depan
  indices.push(8);
  indices.push(9);
  indices.push(10);

  indices.push(8);
  indices.push(11);
  indices.push(10);

  //belakang
  indices.push(12);
  indices.push(13);
  indices.push(14);

  indices.push(12);
  indices.push(15);
  indices.push(14);

  //sisi kanan
  indices.push(12);
  indices.push(8);
  indices.push(11);

  indices.push(12);
  indices.push(15);
  indices.push(11);

  //sisi kiri
  indices.push(13);
  indices.push(9);
  indices.push(10);

  indices.push(13);
  indices.push(14);
  indices.push(10);

  //bagian bawah
  indices.push(8);
  indices.push(12);
  indices.push(13);

  indices.push(8);
  indices.push(9);
  indices.push(13);

  //bagian atas
  indices.push(11);
  indices.push(15);
  indices.push(14);

  indices.push(11);
  indices.push(10);
  indices.push(14);

  return indices;
}

function selimutAtasFaces() {
  var indices = [];

  //belakang
  indices.push(16);
  indices.push(17);
  indices.push(18);

  indices.push(16);
  indices.push(19);
  indices.push(18);

  //depan
  indices.push(20);
  indices.push(21);
  indices.push(22);

  indices.push(20);
  indices.push(23);
  indices.push(22);

  //sisi kanan
  indices.push(20);
  indices.push(16);
  indices.push(19);

  indices.push(20);
  indices.push(23);
  indices.push(19);

  //sisi kiri
  indices.push(21);
  indices.push(17);
  indices.push(18);

  indices.push(21);
  indices.push(22);
  indices.push(18);

  //bagian bawah
  indices.push(16);
  indices.push(20);
  indices.push(21);

  indices.push(16);
  indices.push(17);
  indices.push(21);

  //bagian atas
  indices.push(19);
  indices.push(23);
  indices.push(22);

  indices.push(19);
  indices.push(18);
  indices.push(22);

  return indices;
}

function selimutBawahFaces() {
  var indices = [];

  //belakang
  indices.push(24);
  indices.push(25);
  indices.push(26);

  indices.push(24);
  indices.push(27);
  indices.push(26);

  //depan
  indices.push(28);
  indices.push(29);
  indices.push(30);

  indices.push(28);
  indices.push(31);
  indices.push(30);

  //sisi kanan
  indices.push(24);
  indices.push(28);
  indices.push(31);

  indices.push(24);
  indices.push(27);
  indices.push(31);

  //sisi kiri
  indices.push(25);
  indices.push(29);
  indices.push(30);

  indices.push(25);
  indices.push(26);
  indices.push(30);

  //bagian bawah
  indices.push(24);
  indices.push(25);
  indices.push(29);

  indices.push(24);
  indices.push(28);
  indices.push(29);

  //bagian atas
  indices.push(26);
  indices.push(27);
  indices.push(31);

  indices.push(26);
  indices.push(30);
  indices.push(31);

  return indices;
}

//KARPET
function createKarpet(startX, startY, startZ, x1, x2, y1, y2, z1, z2, colors1) {
  var vertices = [];

  //depan
  vertices.push(x2 + startX, startY, z2 + startZ, ...colors1[2]); //kanan bawah 0
  vertices.push(x2 - startX, startY, z2 + startZ, ...colors1[2]); //kiri bawah 1
  vertices.push(x2 - startX, startY + y1, z2 + startZ, ...colors1[0]); //kiri atas 2
  vertices.push(x2 + startX, startY + y1, z2 + startZ, ...colors1[0]); //kanan atas 3

  //belakang
  vertices.push(x2 + startX, startY, z2 - startZ, ...colors1[2]); //kanan bawah 4
  vertices.push(x2 - startX, startY, z2 - startZ, ...colors1[2]); //kiri bawah 5
  vertices.push(x2 - startX, startY + y1, z2 - startZ, ...colors1[0]); //kiri atas 6
  vertices.push(x2 + startX, startY + y1, z2 - startZ, ...colors1[1]); //kanan atas 7

  return vertices;
}

var colors1 = [
  [0.9412, 0.6275, 0.6275], //0
  [1, 1, 1], //1
  [0.8039, 0.6118, 0.7451], //2
];

function karpetFaces() {
  var indices = [];

  //depan
  indices.push(0);
  indices.push(1);
  indices.push(2);

  indices.push(0);
  indices.push(3);
  indices.push(2);

  //belakang
  indices.push(4);
  indices.push(5);
  indices.push(6);

  indices.push(4);
  indices.push(7);
  indices.push(6);

  //sisi kanan
  indices.push(4);
  indices.push(0);
  indices.push(3);

  indices.push(4);
  indices.push(7);
  indices.push(3);

  //sisi kiri
  indices.push(5);
  indices.push(1);
  indices.push(2);

  indices.push(5);
  indices.push(6);
  indices.push(2);

  //bagian bawah
  indices.push(0);
  indices.push(4);
  indices.push(5);

  indices.push(0);
  indices.push(1);
  indices.push(5);

  //bagian atas
  indices.push(3);
  indices.push(7);
  indices.push(6);

  indices.push(3);
  indices.push(2);
  indices.push(6);

  return indices;
}

//TV
function createTV(startX, startY, startZ, x1, y1, y2, y3, z1, z2, z3, z4, colors2) {
  var vertices = [];

  //meja1 bagian depan
  vertices.push(0 + startX, startY, z4 + startZ, ...colors2[0]); //kanan atas 0
  vertices.push(0 - startX, startY, z4 + startZ, ...colors2[0]); //kiri atas 1
  vertices.push(0 - startX, startY - y1, z4 + startZ, ...colors2[2]); //kiri bawah 2
  vertices.push(0 + startX, startY - y1, z4 + startZ, ...colors2[2]); //kanan bawah 3

  //meja1 bagian belakang
  vertices.push(0 + startX, startY, z4 - startZ, ...colors2[0]); //kanan atas 4
  vertices.push(0 - startX, startY, z4 - startZ, ...colors2[0]); //kiri atas 5
  vertices.push(0 - startX, startY - y1, z4 - startZ, ...colors2[2]); //kiri bawah 6
  vertices.push(0 + startX, startY - y1, z4 - startZ, ...colors2[2]); //kanan bawah 7

  //meja2 bagian depan
  vertices.push(0 + startX - x1, startY - y1 - 0.01, z4 + startZ - 1, ...colors2[0]); //kanan atas 8
  vertices.push(0 - startX + x1, startY - y1 - 0.01, z4 + startZ - 1, ...colors2[0]); //kiri atas 9
  vertices.push(0 - startX + x1, startY - y1 - 0.01 - y2, z4 + startZ - 1, ...colors2[2]); //kiri bawah 10
  vertices.push(0 + startX - x1, startY - y1 - 0.01 - y2, z4 + startZ - 1, ...colors2[2]); //kanan bawah 11

  //meja2 bagian belakang
  vertices.push(0 + startX - x1, startY - y1 - 0.01, z4 - startZ + 1, ...colors2[0]); //kanan atas 12
  vertices.push(0 - startX + x1, startY - y1 - 0.01, z4 - startZ + 1, ...colors2[0]); //kiri atas 13
  vertices.push(0 - startX + x1, startY - y1 - 0.01 - y2, z4 - startZ + 1, ...colors2[2]); //kiri bawah 14
  vertices.push(0 + startX - x1, startY - y1 - 0.01 - y2, z4 - startZ + 1, ...colors2[2]); //kanan bawah 15

  //tv bagian depan
  vertices.push(0 + startX - 5, startY + 0.01, z4 + startZ - z2, ...colors2[3]); //kanan bawah 16
  vertices.push(0 - startX + 5, startY + 0.01, z4 + startZ - z2, ...colors2[3]); //kiri bawah 17
  vertices.push(0 - startX + 5, startY + 0.01 + y3, z4 + startZ - z2, ...colors2[3]); //kiri atas 18
  vertices.push(0 + startX - 5, startY + 0.01 + y3, z4 + startZ - z2, ...colors2[3]); //kanan atas 19

  //tv bagian belakang
  vertices.push(0 + startX - 5, startY + 0.01, z4 - startZ + z1, ...colors2[3]); //kanan bawah 20
  vertices.push(0 - startX + 5, startY + 0.01, z4 - startZ + z1, ...colors2[3]); //kiri bawah 21
  vertices.push(0 - startX + 5, startY + 0.01 + y3, z4 - startZ + z1, ...colors2[3]); //kiri atas 22
  vertices.push(0 + startX - 5, startY + 0.01 + y3, z4 - startZ + z1, ...colors2[3]); //kanan atas 23

  //layar bagian depan
  vertices.push(0 + startX - 6.2, startY + 0.01 + 1.2, z4 - 0 - startZ + z1 + 0.5, ...colors2[4]); //kanan bawah 24
  vertices.push(0 - startX + 6.2, startY + 0.01 + 1.2, z4 - 0 - startZ + z1 + 0.5, ...colors2[4]); //kiri bawah 25
  vertices.push(0 - startX + 6.2, startY + 0.01 + y3 - 1.2, z4 - 0 - startZ + z1 + 0.5, ...colors2[1]); //kiri atas 26
  vertices.push(0 + startX - 6.2, startY + 0.01 + y3 - 1.2, z4 - 0 - startZ + z1 + 0.5, ...colors2[4]); //kanan atas 27

  //layar bagian belakang
  vertices.push(0 + startX - 6.2, startY + 0.01 + 1.2, z4 - startZ + z1 - z3, ...colors2[4]); //kanan bawah 28
  vertices.push(0 - startX + 6.2, startY + 0.01 + 1.2, z4 - startZ + z1 - z3, ...colors2[4]); //kiri bawah 29
  vertices.push(0 - startX + 6.2, startY + 0.01 + y3 - 1.2, z4 - startZ + z1 - z3, ...colors2[1]); //kiri atas 30
  vertices.push(0 + startX - 6.2, startY + 0.01 + y3 - 1.2, z4 - startZ + z1 - z3, ...colors2[4]); //kanan atas 31

  return vertices;
}

var colors2 = [
  [0.6824, 0.4039, 0.1294], //0
  [1, 1, 1], //1
  [0.6471, 0.3804, 0.1176], //2
  [0.1647, 0.1608, 0.1569], //3
  [0.6, 0.8, 1], //4
];

function meja1Faces() {
  var indices = [];

  //depan
  indices.push(0);
  indices.push(1);
  indices.push(2);

  indices.push(0);
  indices.push(3);
  indices.push(2);

  //belakang
  indices.push(4);
  indices.push(5);
  indices.push(6);

  indices.push(4);
  indices.push(7);
  indices.push(6);

  //sisi kanan
  indices.push(4);
  indices.push(0);
  indices.push(3);

  indices.push(4);
  indices.push(7);
  indices.push(3);

  //sisi kiri
  indices.push(5);
  indices.push(1);
  indices.push(2);

  indices.push(5);
  indices.push(6);
  indices.push(2);

  //bagian bawah
  indices.push(0);
  indices.push(4);
  indices.push(5);

  indices.push(0);
  indices.push(1);
  indices.push(5);

  //bagian atas
  indices.push(3);
  indices.push(7);
  indices.push(6);

  indices.push(3);
  indices.push(2);
  indices.push(6);

  return indices;
}

function meja2Faces() {
  var indices = [];

  //depan
  indices.push(8);
  indices.push(9);
  indices.push(10);

  indices.push(8);
  indices.push(11);
  indices.push(10);

  //belakang
  indices.push(12);
  indices.push(13);
  indices.push(14);

  indices.push(12);
  indices.push(15);
  indices.push(14);

  //sisi kanan
  indices.push(8);
  indices.push(12);
  indices.push(15);

  indices.push(8);
  indices.push(11);
  indices.push(15);

  //sisi kiri
  indices.push(9);
  indices.push(13);
  indices.push(14);

  indices.push(9);
  indices.push(10);
  indices.push(14);

  //bagian bawah
  indices.push(11);
  indices.push(10);
  indices.push(14);

  indices.push(11);
  indices.push(15);
  indices.push(14);

  //bagian atas
  indices.push(8);
  indices.push(9);
  indices.push(13);

  indices.push(8);
  indices.push(12);
  indices.push(13);

  return indices;
}

function tvFaces() {
  var indices = [];

  //depan
  indices.push(16);
  indices.push(17);
  indices.push(18);

  indices.push(16);
  indices.push(19);
  indices.push(18);

  //belakang
  indices.push(20);
  indices.push(21);
  indices.push(22);

  indices.push(20);
  indices.push(23);
  indices.push(22);

  //sisi kanan
  indices.push(16);
  indices.push(20);
  indices.push(23);

  indices.push(16);
  indices.push(19);
  indices.push(23);

  //sisi kiri
  indices.push(17);
  indices.push(21);
  indices.push(22);

  indices.push(17);
  indices.push(18);
  indices.push(22);

  //bagian bawah
  indices.push(16);
  indices.push(17);
  indices.push(21);

  indices.push(16);
  indices.push(20);
  indices.push(21);

  //bagian atas
  indices.push(19);
  indices.push(18);
  indices.push(22);

  indices.push(19);
  indices.push(23);
  indices.push(22);

  return indices;
}

function layarFaces() {
  var indices = [];

  //depan
  indices.push(24);
  indices.push(25);
  indices.push(26);

  indices.push(24);
  indices.push(27);
  indices.push(26);

  //belakang
  indices.push(28);
  indices.push(29);
  indices.push(30);

  indices.push(28);
  indices.push(31);
  indices.push(30);

  //sisi kanan
  indices.push(24);
  indices.push(28);
  indices.push(31);

  indices.push(24);
  indices.push(27);
  indices.push(31);

  //sisi kiri
  indices.push(25);
  indices.push(29);
  indices.push(30);

  indices.push(25);
  indices.push(26);
  indices.push(30);

  //bagian bawah
  indices.push(24);
  indices.push(25);
  indices.push(29);

  indices.push(24);
  indices.push(28);
  indices.push(29);

  //bagian atas
  indices.push(27);
  indices.push(26);
  indices.push(30);

  indices.push(27);
  indices.push(31);
  indices.push(30);

  return indices;
}

function createCube(x, y, z, width, height, depth, r, g, b) {
  const halfWidth = width / 2;
  const halfHeight = height / 2;
  const halfDepth = depth / 2;

  const vertices = [
    // Front face
    x - halfWidth, y + halfHeight, z + halfDepth, r, g, b,
    x + halfWidth, y + halfHeight, z + halfDepth, r, g, b,
    x + halfWidth, y - halfHeight, z + halfDepth, r, g, b,
    x - halfWidth, y - halfHeight, z + halfDepth, r, g, b,
    // Back face
    x - halfWidth, y + halfHeight, z - halfDepth, r, g, b,
    x + halfWidth, y + halfHeight, z - halfDepth, r, g, b,
    x + halfWidth, y - halfHeight, z - halfDepth, r, g, b,
    x - halfWidth, y - halfHeight, z - halfDepth, r, g, b,
    // Top face
    x - halfWidth, y + halfHeight, z - halfDepth, r, g, b,
    x + halfWidth, y + halfHeight, z - halfDepth, r, g, b,
    x + halfWidth, y + halfHeight, z + halfDepth, r, g, b,
    x - halfWidth, y + halfHeight, z + halfDepth, r, g, b,
    // Bottom face
    x - halfWidth, y - halfHeight, z - halfDepth, r, g, b,
    x + halfWidth, y - halfHeight, z - halfDepth, r, g, b,
    x + halfWidth, y - halfHeight, z + halfDepth, r, g, b,
    x - halfWidth, y - halfHeight, z + halfDepth, r, g, b,
    // Right face
    x + halfWidth, y + halfHeight, z - halfDepth, r, g, b,
    x + halfWidth, y + halfHeight, z + halfDepth, r, g, b,
    x + halfWidth, y - halfHeight, z + halfDepth, r, g, b,
    x + halfWidth, y - halfHeight, z - halfDepth, r, g, b,
    // Left face
    x - halfWidth, y + halfHeight, z - halfDepth, r, g, b,
    x - halfWidth, y + halfHeight, z + halfDepth, r, g, b,
    x - halfWidth, y - halfHeight, z + halfDepth, r, g, b,
    x - halfWidth, y - halfHeight, z - halfDepth, r, g, b,
  ];

  const faces = [
    0, 1, 2, 0, 2, 3, // Front face
    4, 5, 6, 4, 6, 7, // Back face
    8, 9, 10, 8, 10, 11, // Top face
    12, 13, 14, 12, 14, 15, // Bottom face
    16, 17, 18, 16, 18, 19, // Right face
    20, 21, 22, 20, 22, 23, // Left face
  ];

  return { vertices, faces };
}