function main() {
  //setup
  var CANVAS = document.getElementById("mycanvas");
  CANVAS.width = window.innerWidth;
  CANVAS.height = window.innerHeight;

  var drag = false;
  var X_prev = 0;
  var Y_prev = 0;

  var dX = 0;
  var dY = 0;

  var THETA = 0;
  var ALPHA = 0;

  var FRICTION = 0.9;

  var keyState = {};

  var mouseDown = function (e) {
    drag = true;
    X_prev = e.pageX;
    Y_prev = e.pageY;
  };

  var mouseUp = function (e) {
    drag = false;
  };

  var mouseMove = function (e) {
    if (!drag) {
      return false;
    }
    dX = e.pageX - X_prev;
    dY = e.pageY - Y_prev;
    console.log(dX + " " + dY);
    X_prev = e.pageX;
    Y_prev = e.pageY;

    THETA += (dX * 2 * Math.PI) / CANVAS.width;
    ALPHA += (dY * 2 * Math.PI) / CANVAS.height;
  };

  var keyDownHandler = function (e) {
    keyState[e.key] = true;
  };

  var keyUpHandler = function (e) {
    keyState[e.key] = false;
  };

  CANVAS.addEventListener("mousedown", mouseDown, false);
  CANVAS.addEventListener("mouseup", mouseUp, false);
  CANVAS.addEventListener("mouseout", mouseUp, false);
  CANVAS.addEventListener("mousemove", mouseMove, false);
  window.addEventListener("keydown", keyDownHandler, false);
  window.addEventListener("keyup", keyUpHandler, false);

  try {
    GL = CANVAS.getContext("webgl", { antialias: true });
  } catch (e) {
    alert(e);
    return false;
  }
  //shaders
  var shader_vertex_source = `
        attribute vec3 position;
        attribute vec3 color;
  
        uniform mat4 PMatrix;
        uniform mat4 VMatrix;
        uniform mat4 MMatrix;
       
        varying vec3 vColor;
        void main(void) {
        gl_Position = PMatrix*VMatrix*MMatrix*vec4(position, 1.);
        vColor = color;
  
        gl_PointSize=20.0;
        }`;

  var shader_fragment_source = `
        precision mediump float;
        varying vec3 vColor;
        // uniform vec3 color;
  
        uniform float greyScality;
  
        void main(void) {
        float greyScaleValue = (vColor.r + vColor.g + vColor.b)/3.;
        vec3 greyScaleColor = vec3(greyScaleValue, greyScaleValue, greyScaleValue);
        vec3 color = mix(greyScaleColor, vColor, greyScality);
        gl_FragColor = vec4(color, 1.);
        }`;

  //matrix
  POINTS: var PROJECTION_MATRIX = LIBS.get_projection(
    30,
    CANVAS.width / CANVAS.height,
    10,
    1000
  );
  var VIEW_MATRIX = LIBS.get_I4();
  var MODEL_MATRIX = LIBS.get_I4();
  var MODEL_MATRIX1 = LIBS.get_I4();
  var MODEL_MATRIX2 = LIBS.get_I4();
  var MODEL_MATRIX3 = LIBS.get_I4();
  LIBS.translateZ(VIEW_MATRIX, -150);
  LIBS.translateY(VIEW_MATRIX, -10);

  //Object

  //Hello Kitty

  //badan
  var badan = new MyObject(
    createHalfSphere(0, -9.85, 0, 6, 9, 4.5, 100, 100, 1, 0.2, 0.42).positions,
    createHalfSphere(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  badan.setup();

  var badan1 = new MyObject(
    createSphere(0, -9.85, 0, 6, 0, 4.5, 100, 100, 1, 0.2, 0.42).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  badan1.setup();

  var badan2 = new MyObject(
    createLeher(1.8, -3.43, 3.1589, 0.1, 1, 0.5535, 0.529, 0.808, 0.922),
    leherFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  badan2.setup();

  var kancing_baju_kanan = new MyObject(
    createSphere(2.4, -3.85, 1.9, 0.75, 0.75, 1, 100, 100, 1, 1, 1).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kancing_baju_kanan.setup();

  var kancing_baju_kiri = new MyObject(
    createSphere(-2.4, -3.85, 1.9, 0.75, 0.75, 1, 100, 100, 1, 1, 1).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kancing_baju_kiri.setup();

  //tangan
  var lengan_kanan = new MyObject(
    createCylinder(3.2, -2.55, 0, 6, 1.1, 3, 100, 31, 0.529, 0.808, 0.922).positions,
    createCylinder(0, -6.3, 0, 4, 3, 3, 100, 100, 0, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  lengan_kanan.setup();

  var lengan_kiri = new MyObject(
    createCylinder(-3.2, -2.55, 0, 6, 1.1, 3, 100, -31, 0.529, 0.808, 0.922).positions,
    createCylinder(0, -6.3, 0, 4, 3, 3, 100, 100, 0, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  lengan_kiri.setup();

  var tangan_kanan = new MyObject(
    createCone(1.53, 8.75, 0, 1.15, 2, 1.15, 100, 100, -2, 1, 1, 1).positions,
    createCone(0, 5, 0, 2, 2, 100, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  tangan_kanan.setup();

  var tangan_kiri = new MyObject(
    createCone(-1.53, 8.75, 0, 1.15, 2, 1.15, 100, 100, 2, 1, 1, 1).positions,
    createCone(0, 5, 0, 2, 2, 100, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  tangan_kiri.setup();

  //kaki
  var kaki_kanan = new MyObject(
    createSphere(3, -10.2, 0, 3, 3.15, 3.3, 100, 100, 1, 1, 1).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kaki_kanan.setup();

  var kaki_kiri = new MyObject(
    createSphere(-3, -10.2, 0, 3, 3.15, 3.3, 100, 100, 1, 1, 1).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kaki_kiri.setup();

  //kepala
  var kepala = new MyObject(
    createSphere(0, 3, 0, 7.95, 6, 5.8, 100, 100, 1, 1, 1).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kepala.setup();

  //bagian kepala
  var mata_kanan = new MyObject(
    createSphere(3, 2.1, 5.33, 0.38, 0.48, 0.275, 100, 100, 0, 0, 0).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  mata_kanan.setup();

  var mata_kiri = new MyObject(
    createSphere(-3, 2.1, 5.33, 0.38, 0.48, 0.275, 100, 100, 0, 0, 0).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  mata_kiri.setup();

  var hidung_belakang = new MyObject(
    createSphere(0, 1.15, 5.25, 0.85, 0.62, 0.275, 100, 100, 0, 0, 0).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  hidung_belakang.setup();

  var hidung_depan = new MyObject(
    createSphere(0, 0.88, 5.29, 0.5, 0.22, 0.28, 100, 100, 1, 1, 0).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  hidung_depan.setup();

  var telinga_kanan = new MyObject(
    createCone(-0.5, 11.7, 0, 2.75, 4.5, 2.75, 100, 100, -0.65, 1, 1, 1).positions,
    createCone(0, 5, 0, 2, 2, 100, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  telinga_kanan.setup();

  var telinga_kiri = new MyObject(
    createCone(0.5, 11.7, 0, 2.75, 4.5, 2.75, 100, 100, 0.65, 1, 1, 1).positions,
    createCone(0, 5, 0, 2, 2, 100, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  telinga_kiri.setup();

  var topi = new MyObject(
    createCone1(3, 5, 0, 7.65, 0, 100, 0.2902, 0.5216, 0.9373, 0).positions,
    createCone1(0, -6.3, 0, 4, 3, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  topi.setup();

  var bolaTopi = new MyObject(
    createSphere(0, 12.65, -0.3, 1, 1, 1, 100, 100, 1, 1, 1).positions,
    createSphere(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  bolaTopi.setup();

  //Badtz-Maru

  var head = new MyObject(
    createSphere2(0, 1, 0, 7, 5.5, 5, 100, 100, 0, 0, 0).vertices,
    createSphere2(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  head.setup();

  var body = new MyObject(
    createHalfSphere2(0, -10.5, 0, 6.5, 8, 5, 100, 100, 0, 0, 0).vertices,
    createHalfSphere2(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  body.setup();

  var isibody = new MyObject(
    createHalfSphere2(0, -10, 0.45, 5.75, 6.25, 5, 100, 100, 255, 255, 255).vertices,
    createHalfSphere2(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  isibody.setup();

  var alasPenutup = new MyObject(
    createHalfSphere2(0, -10.5, 0, 6.5, 0.5, 5, 100, 100, 0, 0, 0).vertices,
    createHalfSphere2(0, -8, 0, 6.5, 8, 5, 100, 100, 0, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  alasPenutup.setup();

  var mataKiri = new MyObject(
    createHalfSphere2(-2.25, 1, 3.25, 2.5, -2.15, 2, 100, 100, 255, 255, 255).vertices,
    createHalfSphere2(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  mataKiri.setup();

  var mataKanan = new MyObject(
    createHalfSphere2(2.75, 1, 3.25, 2.5, -2.15, 2, 100, 100, 255, 255, 255).vertices,
    createHalfSphere2(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  mataKanan.setup();

  var bolaMataKiri = new MyObject(
    createHalfSphere2(-2.25, 1, 5, 0.55, -0.65, 1, 100, 100, 0, 0, 0).vertices,
    createHalfSphere2(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  bolaMataKiri.setup();

  var bolaMataKanan = new MyObject(
    createHalfSphere2(2.75, 1, 5, 0.55, -0.65, 1, 100, 100, 0, 0, 0).vertices,
    createHalfSphere2(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  bolaMataKanan.setup();

  var rambutPertama = new MyObject(
    createCone2(2.25, 7, -4, 2.5, 0, 100, Math.PI / 2, 0, 0, 0).vertices,
    createCone2(0, -6.3, 0, 4, 3, 100, 0, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  rambutPertama.setup();

  var rambutKedua = new MyObject(
    createCone2(2.25, 7, -1.25, 2.5, 0, 100, Math.PI / 2, 0, 0, 0).vertices,
    createCone2(0, -6.3, 0, 4, 3, 100, 0, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  rambutKedua.setup();

  var rambutKetiga = new MyObject(
    createCone2(2.25, 7, 1.25, 2.5, 0, 100, Math.PI / 2, 0, 0, 0).vertices,
    createCone2(0, -6.3, 0, 4, 3, 100, 0, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  rambutKetiga.setup();

  var rambutKeempat = new MyObject(
    createCone2(2.25, 7, 4, 2.5, 0, 100, Math.PI / 2, 0, 0, 0).vertices,
    createCone2(0, -6.3, 0, 4, 3, 100, 0, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  rambutKeempat.setup();

  var tanganKiri = new MyObject(
    createSphere2(-3.5, -6.5, 1.0, 4.5, 0.9, 1.1, 100, 100, 0, 0, 0).vertices,
    createSphere2(2, 2, 2, 3, 1.25, 0.5, 100, 100, 0, 1, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  tanganKiri.setup();

  var tanganKanan = new MyObject(
    createSphere2(4.5, -6.5, 1.0, 4.5, 0.9, 1.1, 100, 100, 0, 0, 0).vertices,
    createSphere2(2, 2, 2, 3, 1.25, 0.5, 100, 100, 0, 1, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  tanganKanan.setup();

  var kakiKiri = new MyObject(
    createRightAngleTrapezoidalPrism(3, -12.5, 2, 4, 2, 2, 3, 255, 255, 0).vertices,
    createRightAngleTrapezoidalPrism(0, 0, 0, 6, 4, 10, 5, 0, 0, 1).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  kakiKiri.setup();

  var kakiKanan = new MyObject(
    createRightAngleTrapezoidalPrism(-4, -12.5, 2, 4, 2, 2, 3, 255, 255, 0).vertices,
    createRightAngleTrapezoidalPrism(0, 0, 0, 6, 4, 10, 5, 0, 0, 1).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  kakiKanan.setup();

  var paruh = new MyObject(
    createParuh(2, -2.5, 4.75, 0.1, 0, 2, 1, 1, 1, 0, 0, 0, 0),
    leherParuh(),
    shader_vertex_source,
    shader_fragment_source
  );
  paruh.setup();

  var mulut = new MyObject(
    createParuhDalam(2, -2.5, 4.75, 0.1, 0, 2, 1, 1, 1, 1),
    leherParuhDalam(),
    shader_vertex_source,
    shader_fragment_source
  );
  mulut.setup();

  // var garisKurvaBardtz = [];
  //   garisKurvaBardtz = createBezierRectangularPrism(-0.15, -0.25 + 0.75 + 0.5, 0, 0.30 + 0.5, 0, 0.30 + 0.5, 0.15, -0.25 + 0.75 + 0.5, 1.3, 0, 0, 0, 100);
  //   var garisKurvaBardtz_vertex = garisKurvaBardtz[0];
  //   var garisKurvaBardtz_faces = garisKurvaBardtz[1];
  // var kurvaBardtz = new myObject(garisKurvaBardtz_vertex, garisKurvaBardtz_faces, shader_vertex_source, shader_fragment_source);
  // kurvaBardtz.setup();

  //Keropi
  var badanKeropi = new MyObject(
    createHalfSphere3(0, -10.35, 0, 7, 9, 6, 100, 100, 0.4, 0.733, 0.416).positions,
    createHalfSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  badanKeropi.setup();

  var badanKeropi1 = new MyObject(
    createSphere3(0, -10, 0, 7, 0, 6, 100, 100, 0.4, 0.733, 0.416).positions,
    createSphere3(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  badanKeropi1.setup();

  //kepalaKeropi
  var kepalaKeropi = new MyObject(
    createSphere3(0, 0, 0, 8.5, 5.5, 7.5, 100, 100, 0.4, 1, 0.416).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kepalaKeropi.setup();

  var mataKiriKeropi = new MyObject(
    createSphere3(3.3, 5, 0.8, 3.8, 3.8, 3.8, 100, 100, 1, 1, 1).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  mataKiriKeropi.setup();

  var mataKananKeropi = new MyObject(
    createSphere3(-3.3, 5, 0.8, 3.8, 3.8, 3.8, 100, 100, 1, 1, 1).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  mataKananKeropi.setup();

  var pupilKiriKeropi = new MyObject(
    createSphere3(-2.5, 5, 3.8, 1, 1, 1, 100, 100, 0, 0, 0).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  pupilKiriKeropi.setup();

  var pupilKananKeropi = new MyObject(
    createSphere3(2.5, 5, 3.8, 1, 1, 1, 100, 100, 0, 0, 0).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  pupilKananKeropi.setup();

  var kelopakmataKiriKeropi = new MyObject(
    createSphere3(-3.3, 5.1, 0, 4.1, 3.9, 3.9, 100, 100, 0.4, 1, 0.416).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kelopakmataKiriKeropi.setup();

  var kelopakmataKananKeropi = new MyObject(
    createSphere3(3.3, 5.1, 0, 4.1, 3.9, 3.9, 100, 100, 0.4, 1, 0.416).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kelopakmataKananKeropi.setup();

  var pipiKiriKeropi = new MyObject(
    createSphere3(-5, 0, 5.3, 1.1, 1.3, 0.8, 100, 100, 1, 0.5, 0.5).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  pipiKiriKeropi.setup();

  var pipiKananKeropi = new MyObject(
    createSphere3(5, 0, 5.3, 1.1, 1.3, 0.8, 100, 100, 1, 0.5, 0.5).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  pipiKananKeropi.setup();

  var tanganKiriKeropi = new MyObject(
    createCylinder3(-6.1, -6.3, 0, 2.5, 1.5, 900, 100, 0.5, 0.4, 1, 0.416).positions, // Koordinat tabung dengan radius 1, tinggi 3, dan warna (0.4, 1, 1)
    createCylinder3(0, 0, 0, 1, 3, 10000, 100, 1, 1, 1).indices, // Indeks tabung
    shader_vertex_source,
    shader_fragment_source
  );
  tanganKiriKeropi.setup();

  var telapakKiriKeropi = new MyObject(
    createSphere3(-8.2, -8.3, 0, 1.25, 1.25, 1.5, 100, 100, 0.4, 1, 0.416).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  telapakKiriKeropi.setup();

  var tanganKananKeropi = new MyObject(
    createCylinder3(5.48, -7.6, 0, 2.5, 1.5, 900, 100, 2.68, 0.4, 1, 0.416).positions, // Koordinat tabung dengan radius 1, tinggi 3, dan warna (0.4, 1, 1)
    createCylinder3(0, 0, 0, 1, 3, 1000, 100, 1, 1, 1).indices, // Indeks tabung
    shader_vertex_source,
    shader_fragment_source
  );
  tanganKananKeropi.setup();

  var telapakKananKeropi = new MyObject(
    createSphere3(8.2, -8.2, 0, 1.25, 1.3, 1.5, 100, 100, 0.4, 1, 0.416).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  telapakKananKeropi.setup();

  var kakiKiriKeropi = new MyObject(
    createSphere3(-3.3, -11.5, 0, 2.5, 3, 3, 100, 100, 0.4, 1, 0.416).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kakiKiriKeropi.setup();

  var kakiKananKeropi = new MyObject(
    createSphere3(3.3, -11.5, 0, 2.5, 3, 3, 100, 100, 0.4, 1, 0.416).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  kakiKananKeropi.setup();

  var topiKeropi = new MyObject(
    createCone2(3.25, 7, 0, 4.5, -0.2, 100, Math.PI / 2, 0.54, 0.81, 0.94).vertices,
    createCone2(0, -6.3, 0, 4, 3, 100, 0, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  topiKeropi.setup();  
  
  var bulatTopiKeropi = new MyObject(
    createSphere3(0, 11.5 , 0, 0.8, 0.8, 0.8, 100, 100, 1, 1, 1).positions,
    createSphere3(0, 0, 0, 2, 2, 2, 100, 100, 0, 0, 0).indices,
    shader_vertex_source,
    shader_fragment_source
  );
  bulatTopiKeropi.setup();


  //Assets

  //Alas
  var alasLantai = new MyObject(
    createCube(0, -14.5, 0, 1000, 2.8, 1000, 0.7529, 0.7961, 1).vertices,
    createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.7529, 0.7961, 1).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  alasLantai.setup();

  //Kamar
  var kasur1 = new MyObject(
    createKasur(10, -13.5, 15, 2, 0, 1.5, 0.8, 7, -50, colors),
    kasurFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  kasur1.setup();

  var bantal1 = new MyObject(
    createKasur(10, -13.5, 15, 2, 0, 1.5, 0.8, 7, -50, colors),
    bantalFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  bantal1.setup();

  var selimut_atas1 = new MyObject(
    createKasur(10, -13.5, 15, 2, 0, 1.5, 0.8, 7, -50, colors),
    selimutAtasFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  selimut_atas1.setup();

  var selimut_bawah1 = new MyObject(
    createKasur(10, -13.5, 15, 2, 0, 1.5, 0.8, 7, -50, colors),
    selimutBawahFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  selimut_bawah1.setup();

  var kasur2 = new MyObject(
    createKasur(10, -13.5, 15, 2, 21.5, 1.5, 0.8, 7, -50, colors),
    kasurFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  kasur2.setup();

  var bantal2 = new MyObject(
    createKasur(10, -13.5, 15, 2, 21.5, 1.5, 0.8, 7, -50, colors),
    bantalFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  bantal2.setup();

  var selimut_atas2 = new MyObject(
    createKasur(10, -13.5, 15, 2, 21.5, 1.5, 0.8, 7, -50, colors),
    selimutAtasFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  selimut_atas2.setup();

  var selimut_bawah2 = new MyObject(
    createKasur(10, -13.5, 15, 2, 21.5, 1.5, 0.8, 7, -50, colors),
    selimutBawahFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  selimut_bawah2.setup();

  var kasur3 = new MyObject(
    createKasur(10, -13.5, 15, 2, -21.5, 1.5, 0.8, 7, -50, colors),
    kasurFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  kasur3.setup();

  var bantal3 = new MyObject(
    createKasur(10, -13.5, 15, 2, -21.5, 1.5, 0.8, 7, -50, colors),
    bantalFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  bantal3.setup();

  var selimut_atas3 = new MyObject(
    createKasur(10, -13.5, 15, 2, -21.5, 1.5, 0.8, 7, -50, colors),
    selimutAtasFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  selimut_atas3.setup();

  var selimut_bawah3 = new MyObject(
    createKasur(10, -13.5, 15, 2, -21.5, 1.5, 0.8, 7, -50, colors),
    selimutBawahFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  selimut_bawah3.setup();

  // Meja Makan
  var kakiMeja1 = new MyObject(
    createCube(55.5, -13.5, -21.5, 1, 4, 1, 0.6824, 0.4039, 0.1294).vertices,
    createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  kakiMeja1.setup();

  var kakiMeja2 = new MyObject(
    createCube(80.5, -13.5, -21.5, 1, 4, 1, 0.6824, 0.4039, 0.1294).vertices,
    createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  kakiMeja2.setup();

  var kakiMeja3 = new MyObject(
    createCube(55.5, -13.5, -28.5, 1, 4, 1, 0.6824, 0.4039, 0.1294).vertices,
    createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  kakiMeja3.setup();

  var kakiMeja4 = new MyObject(
    createCube(80.5, -13.5, -28.5, 1, 4, 1, 0.6824, 0.4039, 0.1294).vertices,
    createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  kakiMeja4.setup();

  var intiMeja = new MyObject(
    createCube(67.5, -10.75, -25, 30, 2, 12, 255, 255, 255).vertices,
    createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  intiMeja.setup();

  // //Kursi Meja Makan
  var kursiDuduk = new MyObject(
    createCube(56.5, -6.5, -10, 5, 0.5, 5, 0.6824, 0.4039, 0.1294).vertices,
    createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  kursiDuduk.setup();

  var sandaranKursi = new MyObject(
    createHalfSphere2(55.5, -6.5, -10, 3.25, 5, 1, 100, 100, 255, 255, 255).vertices,
    createHalfSphere2(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  sandaranKursi.setup();

  var sandaranTanganKiri = new MyObject(
    createHalfSphere2(53, -6.5, -10, 1, 2, 3, 100, 100, 1.0, 0.7176, 0.7569).vertices,
    createHalfSphere2(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  sandaranTanganKiri.setup();

  var sandaranTanganKanan = new MyObject(
    createHalfSphere2(59, -6.5, -10, 1, 2, 3, 100, 100, 1.0, 0.7176, 0.7569).vertices,
    createHalfSphere2(0, -6.3, 0, 4, 3, 3, 100, 100, 1, 0, 0).faces,
    shader_vertex_source,
    shader_fragment_source
  );
  sandaranTanganKanan.setup();

  var karpet = new MyObject(
    createKarpet(40, -13.5, 20, 2, 0, 1, 0.8, 7, -30, colors1),
    karpetFaces(),
    shader_vertex_source,
    shader_fragment_source
  );
  karpet.setup();

//TV
var meja1_tv = new MyObject(
  createTV(14, -6.09, 7, 1, 1.4, 6, 10, 2.5, 1.5, 0.25, -30, colors2),
  meja1Faces(),
  shader_vertex_source,
  shader_fragment_source
);
meja1_tv.setup();

var meja2_tv = new MyObject(
  createTV(14, -6.09, 7, 1, 1.4, 6, 10, 2.5, 1.5, 0.25, -30, colors2),
  meja2Faces(),
  shader_vertex_source,
  shader_fragment_source
);
meja2_tv.setup();

var tv = new MyObject(
  createTV(14, -6.09, 7, 1, 1.4, 6, 10, 2.5, 1.5, 0.25, -30, colors2),
  tvFaces(),
  shader_vertex_source,
  shader_fragment_source
);
tv.setup();

var layar = new MyObject(
  createTV(14, -6.09, 7, 1, 1.4, 6, 10, 2.5, 1.5, 0.25, -30, colors2),
  layarFaces(),
  shader_vertex_source,
  shader_fragment_source
);
layar.setup();

  //Jendela
  // var bingkaiJendelaKiri = new MyObject(
  //   createCube(-6.5, 0, 1.0, 1, 12, 1, 255, 255, 255).vertices,
  //   createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
  //   shader_vertex_source,
  //   shader_fragment_source
  // );
  // bingkaiJendelaKiri.setup();

  // var bingkaiJendelaKanan = new MyObject(
  //   createCube(6.5, 0, 1.0, 1, 12, 1, 255, 255, 255).vertices,
  //   createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
  //   shader_vertex_source,
  //   shader_fragment_source
  // );
  // bingkaiJendelaKanan.setup();

  // var bingkaiTengahVertikal = new MyObject(
  //   createCube(0, 0, 1.0, 1, 12, 1, 255, 255, 255).vertices,
  //   createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
  //   shader_vertex_source,
  //   shader_fragment_source
  // );
  // bingkaiTengahVertikal.setup();

  // var bingkaiJendelaAtas = new MyObject(
  //   createCube(0, 5.5, 1.0, 12, 1, 1, 255, 255, 255).vertices,
  //   createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
  //   shader_vertex_source,
  //   shader_fragment_source
  // );
  // bingkaiJendelaAtas.setup();

  // var bingkaiTengahHorizontal = new MyObject(
  //   createCube(0, 0, 1.0, 12, 1, 1, 255, 255, 255).vertices,
  //   createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
  //   shader_vertex_source,
  //   shader_fragment_source
  // );
  // bingkaiTengahHorizontal.setup();

  // var bingkaiJendelaBawah = new MyObject(
  //   createCube(0, -5.5, 1.0, 12, 1, 1, 255, 255, 255).vertices,
  //   createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
  //   shader_vertex_source,
  //   shader_fragment_source
  // );
  // bingkaiJendelaBawah.setup();

  // var bingkaiJendelaKanan = new MyObject(
  //   createCube(6.5, 0, 1.0, 1, 12, 1, 255, 255, 255).vertices,
  //   createCube(4.5, -3.5, 1.0, 1, 4, 2, 0.6824, 0.4039, 0.1294).faces,
  //   shader_vertex_source,
  //   shader_fragment_source
  // );
  // bingkaiJendelaKanan.setup();

  //Parent

  //Hello Kitty
  badan.child.push(badan1);
  badan.child.push(badan2);
  badan.child.push(kancing_baju_kanan);
  badan.child.push(kancing_baju_kiri);
  badan.child.push(lengan_kanan);
  badan.child.push(lengan_kiri);
  badan.child.push(kaki_kanan);
  badan.child.push(kaki_kiri);
  badan.child.push(kepala);
  kepala.child.push(mata_kanan);
  kepala.child.push(mata_kiri);
  kepala.child.push(hidung_belakang);
  kepala.child.push(hidung_depan);
  kepala.child.push(telinga_kanan);
  kepala.child.push(telinga_kiri);
  kepala.child.push(topi);
  kepala.child.push(bolaTopi);
  lengan_kanan.child.push(tangan_kanan);
  lengan_kiri.child.push(tangan_kiri);

  //Badtz-Maru
  body.child.push(head);
  body.child.push(isibody);
  body.child.push(alasPenutup);
  body.child.push(tanganKiri);
  body.child.push(tanganKanan);
  body.child.push(kakiKiri);
  body.child.push(kakiKanan);
  head.child.push(mataKiri);
  head.child.push(mataKanan);
  head.child.push(bolaMataKiri);
  head.child.push(bolaMataKanan);
  head.child.push(rambutPertama);
  head.child.push(rambutKedua);
  head.child.push(rambutKetiga);
  head.child.push(rambutKeempat);
  head.child.push(paruh);
  head.child.push(mulut);

  //Keropi
  badanKeropi.child.push();
  badanKeropi.child.push(badanKeropi1);
  badanKeropi.child.push(kepalaKeropi);
  kepalaKeropi.child.push(mataKiriKeropi);
  kepalaKeropi.child.push(mataKananKeropi);
  kepalaKeropi.child.push(pupilKiriKeropi);
  kepalaKeropi.child.push(pupilKananKeropi);
  kepalaKeropi.child.push(kelopakmataKiriKeropi);
  kepalaKeropi.child.push(kelopakmataKananKeropi);
  kepalaKeropi.child.push(pipiKiriKeropi);
  kepalaKeropi.child.push(pipiKananKeropi);
  badanKeropi.child.push(tanganKiriKeropi);
  badanKeropi.child.push(tanganKananKeropi);
  tanganKiriKeropi.child.push(telapakKiriKeropi);
  tanganKananKeropi.child.push(telapakKananKeropi);
  badanKeropi.child.push(kakiKiriKeropi);
  badanKeropi.child.push(kakiKananKeropi);
  kepalaKeropi.child.push(topiKeropi);
  kepalaKeropi.child.push(bulatTopiKeropi);

  //Assets

  //Alas
  alasLantai.child.push();

  //Kamar
  kasur1.child.push(bantal1);
  kasur1.child.push(selimut_atas1);
  kasur1.child.push(selimut_bawah1);

  kasur2.child.push(bantal2);
  kasur2.child.push(selimut_atas2);
  kasur2.child.push(selimut_bawah2);

  kasur3.child.push(bantal3);
  kasur3.child.push(selimut_atas3);
  kasur3.child.push(selimut_bawah3);

  //Karpet
  karpet.child.push();

  //TV
  meja1_tv.child.push(meja2_tv);
  meja1_tv.child.push(tv);
  meja1_tv.child.push(layar);

  // Meja Makan
  intiMeja.child.push(kakiMeja1);
  intiMeja.child.push(kakiMeja2);
  intiMeja.child.push(kakiMeja3);
  intiMeja.child.push(kakiMeja4);

  kursiDuduk.child.push(sandaranKursi);
  kursiDuduk.child.push(sandaranTanganKiri);
  kursiDuduk.child.push(sandaranTanganKanan);



  // head.child.push(alasPenutup);
  // head.child.push(bingkaiJendelaKiri);
  // head.child.push(bingkaiJendelaKanan);
  // head.child.push(bingkaiTengahVertikal);
  // head.child.push(bingkaiJendelaAtas);
  // head.child.push(bingkaiTengahHorizontal);
  // head.child.push(bingkaiJendelaBawah);

  head.render(VIEW_MATRIX, PROJECTION_MATRIX);

  // ===== DRAWING =====
  GL.clearColor(0.0, 0.0, 0.0, 0.0);

  GL.enable(GL.DEPTH_TEST);
  GL.depthFunc(GL.LEQUAL);

  // Cara ubah sumbu
  body.MODEL_MATRIX1 = LIBS.get_I4;
  LIBS.translateX(MODEL_MATRIX1, 30);

  badanKeropi.MODEL_MATRIX2 = LIBS.get_I4;
  LIBS.translateX(MODEL_MATRIX2, -30)

  let num = 0;
  var scaleFactor = 0.995;

  var time_prev = 0;
  var animate = function (time) {
    GL.viewport(0, 0, CANVAS.width, CANVAS.height);
    GL.clear(GL.COLOR_BUFFER_BIT | GL.D_BUFFER_BIT);
    var dt = time - time_prev;
    time_prev = time;
    var jump = 0;
    var fall = false;
    var jumpStatus = false;
    var stopJumping = false;

    if (time <= 1200) {
      badan.MODEL_MATRIX = LIBS.get_I4();
      LIBS.translateY(MODEL_MATRIX, LIBS.degToRad(time * 0.0015));
    } else if (time <= 1400) {
      LIBS.translateY(MODEL_MATRIX, LIBS.degToRad(time * -0.0015));
    } else if (time <= 2830) {
      temp = LIBS.get_I4();
      LIBS.translateY(badan.MODEL_MATRIX, 0);
      LIBS.rotateY(MODEL_MATRIX, LIBS.degToRad(time * 0.002));
    } else if (time <= 3500) {
      LIBS.translateY(MODEL_MATRIX, LIBS.degToRad(time * 0.005));
      LIBS.rotateX(MODEL_MATRIX, LIBS.degToRad(time * -0.005));
    } else if (time <= 4190) {
      LIBS.translateY(MODEL_MATRIX, LIBS.degToRad(time * -0.005));
      LIBS.rotateX(MODEL_MATRIX, LIBS.degToRad(time * -0.005));
    }else if (time <= 4350) {
      LIBS.translateY(MODEL_MATRIX, LIBS.degToRad(time * 0.005));
    }

    if(time >= 4550)
    {
      if (num >= 100) {
        num -= 100;
        scaleFactor = 1 / scaleFactor
      }
      LIBS.scale(MODEL_MATRIX, scaleFactor, scaleFactor, scaleFactor)
      // else if (time <= 3500) {
      //   var reverseScaleFactor = Math.abs(Math.sin((time * 2 / 3300)));
      //   LIBS.scale(MODEL_MATRIX, 1 / reverseScaleFactor, 1 / reverseScaleFactor, 1 / reverseScaleFactor);
      // } 
      num++;
    }

    if (time <= 1200) {
      body.MODEL_MATRIX1 = LIBS.get_I4();
      LIBS.translateY(MODEL_MATRIX1, LIBS.degToRad(time * 0.0015));
    } else if (time <= 1400) {
      LIBS.translateY(MODEL_MATRIX1, LIBS.degToRad(time * -0.0015));
    } else if (time <= 2830) {
      temp = LIBS.get_I4();
      LIBS.translateY(body.MODEL_MATRIX1, 0);
      LIBS.rotateY(MODEL_MATRIX1, LIBS.degToRad(time * 0.002));
    } else if (time <= 3500) {
      LIBS.translateY(MODEL_MATRIX1, LIBS.degToRad(time * 0.005));
      LIBS.rotateX(MODEL_MATRIX1, LIBS.degToRad(time * -0.005));
      LIBS.rotateY(MODEL_MATRIX1, LIBS.degToRad(time * 0.0055));
    } else if (time <= 4205) {
      LIBS.translateY(MODEL_MATRIX1, LIBS.degToRad(time * -0.005));
      LIBS.rotateX(MODEL_MATRIX1, LIBS.degToRad(time * -0.005));
      LIBS.rotateY(MODEL_MATRIX1, LIBS.degToRad(time * 0.0055));
    }else if (time <= 4350) {
      LIBS.translateY(MODEL_MATRIX1, LIBS.degToRad(time * 0.005));
    }
    if(time >= 4550)
    {
      if (num >= 100) {
        num -= 10;
        scaleFactor = 1 / scaleFactor
      }
      LIBS.scale(MODEL_MATRIX1, scaleFactor, scaleFactor, scaleFactor)
      // else if (time <= 3500) {
      //   var reverseScaleFactor = Math.abs(Math.sin((time * 2 / 3300)));
      //   LIBS.scale(MODEL_MATRIX, 1 / reverseScaleFactor, 1 / reverseScaleFactor, 1 / reverseScaleFactor);
      // } 
      num++;
    }

    if (time <= 1200) {
      badanKeropi.MODEL_MATRIX2 = LIBS.get_I4();
      LIBS.translateY(MODEL_MATRIX2, LIBS.degToRad(time * 0.0015));
    } else if (time <= 1400) {
      LIBS.translateY(MODEL_MATRIX2, LIBS.degToRad(time * -0.0015));
    } else if (time <= 2830) {
      temp = LIBS.get_I4();
      LIBS.translateY(badan.MODEL_MATRIX2, 0);
      LIBS.rotateY(MODEL_MATRIX2, LIBS.degToRad(time * 0.002));
    } else if (time <= 3500) {
      LIBS.translateY(MODEL_MATRIX2, LIBS.degToRad(time * 0.005));
      LIBS.rotateX(MODEL_MATRIX2, LIBS.degToRad(time * -0.005));
      LIBS.rotateY(MODEL_MATRIX2, LIBS.degToRad(time * -0.0055));
    } else if (time <= 4205) {
      LIBS.translateY(MODEL_MATRIX2, LIBS.degToRad(time * -0.005));
      LIBS.rotateX(MODEL_MATRIX2, LIBS.degToRad(time * -0.005));
      LIBS.rotateY(MODEL_MATRIX2, LIBS.degToRad(time * -0.0055));
    }else if (time <= 4350) {
      LIBS.translateY(MODEL_MATRIX2, LIBS.degToRad(time * 0.005));
    }
    if(time >= 4550)
    {
      if (num >= 100) {
        num -= 10;
        scaleFactor = 1 / scaleFactor
      }
      LIBS.scale(MODEL_MATRIX2, scaleFactor, scaleFactor, scaleFactor)
      // else if (time <= 3500) {
      //   var reverseScaleFactor = Math.abs(Math.sin((time * 2 / 3300)));
      //   LIBS.scale(MODEL_MATRIX, 1 / reverseScaleFactor, 1 / reverseScaleFactor, 1 / reverseScaleFactor);
      // } 
      num++;
    }


    // } else if (time <= 1800) {
    //     var translationAmount = LIBS.degToRad(time * 0.002);
    //     LIBS.translateY(MODEL_MATRIX, translationAmount); 
    //     var rotationAmount = LIBS.degToRad(time * 0.002); 
    //     LIBS.rotateY(MODEL_MATRIX, rotationAmount); 
    //     totalRotation += rotationAmount; 
    //     if (totalRotation >= Math.PI * 2) { 
    //         totalRotation -= Math.PI * 2; 
    //     }


    // else {
    //     time >= 1000;
    //   badan.MODEL_MATRIX = LIBS.get_I4();
    //   LIBS.translateY(MODEL_MATRIX, LIBS.degToRad(time * -0.005));
    // // }

    // var time_prev = 0;
    // var isHeadUp = false;
    // var animationDuration = 1000; // Durasi angkat badan (dalam milidetik)

    // var animate = function (time) {
    //     GL.viewport(0, 0, CANVAS.width, CANVAS.height);
    //     GL.clear(GL.COLOR_BUFFER_BIT | GL.D_BUFFER_BIT);
    //     var dt = time - time_prev;
    //     time_prev = time;

    //     if (!isHeadUp) {
    //         if (time <= animationDuration) {
    //             badan.MODEL_MATRIX = LIBS.get_I4();
    //             LIBS.translateY(MODEL_MATRIX, LIBS.degToRad(time * 0.005));
    //         } else {
    //             isHeadUp = true;
    //             animationStartTime = time;
    //         }
    //     } else {
    //         var elapsedTime = time - animationStartTime;
    //         if (elapsedTime <= animationDuration) {
    //             badan.MODEL_MATRIX = LIBS.get_I4();
    //             LIBS.translateY(MODEL_MATRIX, LIBS.degToRad(animationDuration * 0.005 - elapsedTime * 0.005));
    //         } else {
    //             isHeadUp = false; // Reset keadaan untuk animasi selanjutnya
    //         }

    if (!drag) {
      dX *= FRICTION;
      dY *= FRICTION;

      THETA += (dX * 2 * Math.PI) / CANVAS.width;
      ALPHA += (dY * 2 * Math.PI) / CANVAS.height;

      if (keyState["w"]) {
        ALPHA += 0.03;
      }
      if (keyState["s"]) {
        ALPHA -= 0.03;
      }
      if (keyState["a"]) {
        THETA -= 0.03;
      }
      if (keyState["d"]) {
        THETA += 0.03;
      }
    }

    // MODEL_MATRIX = LIBS.get_I4();
    // LIBS.rotateY(MODEL_MATRIX, -THETA);
    // LIBS.rotateX(MODEL_MATRIX, -ALPHA);

    //Hello Kitty
    badan.MODEL_MATRIX = MODEL_MATRIX;
    badan1.MODEL_MATRIX = MODEL_MATRIX;
    badan2.MODEL_MATRIX = MODEL_MATRIX;
    kancing_baju_kanan.MODEL_MATRIX = MODEL_MATRIX;
    kancing_baju_kiri.MODEL_MATRIX = MODEL_MATRIX;
    lengan_kanan.MODEL_MATRIX = MODEL_MATRIX;
    lengan_kiri.MODEL_MATRIX = MODEL_MATRIX;
    tangan_kanan.MODEL_MATRIX = MODEL_MATRIX;
    tangan_kiri.MODEL_MATRIX = MODEL_MATRIX;
    kaki_kanan.MODEL_MATRIX = MODEL_MATRIX;
    kaki_kiri.MODEL_MATRIX = MODEL_MATRIX;
    kepala.MODEL_MATRIX = MODEL_MATRIX;
    mata_kanan.MODEL_MATRIX = MODEL_MATRIX;
    mata_kiri.MODEL_MATRIX = MODEL_MATRIX;
    hidung_belakang.MODEL_MATRIX = MODEL_MATRIX;
    hidung_depan.MODEL_MATRIX = MODEL_MATRIX;
    telinga_kanan.MODEL_MATRIX = MODEL_MATRIX;
    telinga_kiri.MODEL_MATRIX = MODEL_MATRIX;
    topi.MODEL_MATRIX = MODEL_MATRIX;
    bolaTopi.MODEL_MATRIX = MODEL_MATRIX;

    badan.render(VIEW_MATRIX, PROJECTION_MATRIX);
    kepala.render(VIEW_MATRIX, PROJECTION_MATRIX);

    //Badtz-Maru

    head.MODEL_MATRIX = MODEL_MATRIX1;
    body.MODEL_MATRIX1 = MODEL_MATRIX1;
    isibody.MODEL_MATRIX = MODEL_MATRIX1;
    mataKiri.MODEL_MATRIX = MODEL_MATRIX1;
    mataKanan.MODEL_MATRIX = MODEL_MATRIX1;
    bolaMataKiri.MODEL_MATRIX = MODEL_MATRIX1;
    bolaMataKanan.MODEL_MATRIX = MODEL_MATRIX1;
    rambutPertama.MODEL_MATRIX = MODEL_MATRIX1;
    rambutKedua.MODEL_MATRIX = MODEL_MATRIX1;
    rambutKetiga.MODEL_MATRIX = MODEL_MATRIX1;
    rambutKeempat.MODEL_MATRIX = MODEL_MATRIX1;
    alasPenutup.MODEL_MATRIX = MODEL_MATRIX1;
    tanganKiri.MODEL_MATRIX = MODEL_MATRIX1;
    tanganKanan.MODEL_MATRIX = MODEL_MATRIX1;
    kakiKiri.MODEL_MATRIX = MODEL_MATRIX1;
    kakiKanan.MODEL_MATRIX = MODEL_MATRIX1;
    paruh.MODEL_MATRIX = MODEL_MATRIX1;
    mulut.MODEL_MATRIX = MODEL_MATRIX1;

    body.render1(VIEW_MATRIX, PROJECTION_MATRIX);

    //Keropi

    badanKeropi.MODEL_MATRIX2 = MODEL_MATRIX2;
    badanKeropi1.MODEL_MATRIX = MODEL_MATRIX2;
    kepalaKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    mataKiriKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    mataKananKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    pupilKiriKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    pupilKananKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    kelopakmataKiriKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    kelopakmataKananKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    pipiKiriKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    pipiKananKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    tanganKiriKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    tanganKananKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    telapakKiriKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    telapakKananKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    kakiKiriKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    kakiKananKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    topiKeropi.MODEL_MATRIX = MODEL_MATRIX2;
    bulatTopiKeropi.MODEL_MATRIX = MODEL_MATRIX2;

    badanKeropi.render2(VIEW_MATRIX, PROJECTION_MATRIX);

    //Assets

    //Alas Lantai
    alasLantai.MODEL_MATRIX1 = MODEL_MATRIX;
    alasLantai.render(VIEW_MATRIX, PROJECTION_MATRIX);

    //Kasur

    kasur1.MODEL_MATRIX1 = MODEL_MATRIX;
    bantal1.MODEL_MATRIX1 = MODEL_MATRIX;
    selimut_atas1.MODEL_MATRIX1 = MODEL_MATRIX;
    selimut_bawah1.MODEL_MATRIX1 = MODEL_MATRIX;

    kasur1.render(VIEW_MATRIX, PROJECTION_MATRIX);

    kasur2.MODEL_MATRIX1 = MODEL_MATRIX;
    bantal2.MODEL_MATRIX1 = MODEL_MATRIX;
    selimut_atas2.MODEL_MATRIX1 = MODEL_MATRIX;
    selimut_bawah2.MODEL_MATRIX1 = MODEL_MATRIX;

    kasur2.render(VIEW_MATRIX, PROJECTION_MATRIX);

    kasur3.MODEL_MATRIX1 = MODEL_MATRIX;
    bantal3.MODEL_MATRIX1 = MODEL_MATRIX;
    selimut_atas3.MODEL_MATRIX1 = MODEL_MATRIX;
    selimut_bawah3.MODEL_MATRIX1 = MODEL_MATRIX;

    kasur3.render(VIEW_MATRIX, PROJECTION_MATRIX);

    //Karpet
    karpet.MODEL_MATRIX3 = MODEL_MATRIX;

    karpet.render(VIEW_MATRIX, PROJECTION_MATRIX);

    //TV
    meja1_tv.MODEL_MATRIX1 = MODEL_MATRIX;
    meja2_tv.MODEL_MATRIX1 = MODEL_MATRIX;
    tv.MODEL_MATRIX1 = MODEL_MATRIX;
    layar.MODEL_MATRIX1 = MODEL_MATRIX;

    meja1_tv.render(VIEW_MATRIX, PROJECTION_MATRIX);

    kakiMeja1.MODEL_MATRIX3 = MODEL_MATRIX;
    kakiMeja2.MODEL_MATRIX3 = MODEL_MATRIX;
    kakiMeja3.MODEL_MATRIX3 = MODEL_MATRIX;
    kakiMeja4.MODEL_MATRIX3 = MODEL_MATRIX;

    intiMeja.render(VIEW_MATRIX, PROJECTION_MATRIX);

    kursiDuduk.MODEL_MATRIX3 = MODEL_MATRIX;
    sandaranKursi.MODEL_MATRIX3 = MODEL_MATRIX;
    sandaranTanganKiri.MODEL_MATRIX3 = MODEL_MATRIX;
    sandaranTanganKanan.MODEL_MATRIX3 = MODEL_MATRIX;

    kursiDuduk.render(VIEW_MATRIX, PROJECTION_MATRIX);


    // alasPenutup.MODEL_MATRIX = MODEL_MATRIX;
    // bingkaiJendelaKiri.MODEL_MATRIX = MODEL_MATRIX;
    // bingkaiJendelaKanan.MODEL_MATRIX = MODEL_MATRIX;
    // bingkaiTengahVertikal.MODEL_MATRIX = MODEL_MATRIX;
    // bingkaiJendelaAtas.MODEL_MATRIX = MODEL_MATRIX;
    // bingkaiTengahHorizontal.MODEL_MATRIX = MODEL_MATRIX;
    // bingkaiJendelaBawah.MODEL_MATRIX = MODEL_MATRIX;

    window.requestAnimationFrame(animate);
  };
  animate(0);
}
window.addEventListener("load", main);